package com.gabriel.aula0604;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.AdapterView;
import android.widget.ArrayAdapter;
import android.widget.ListView;
import android.widget.Toast;

public class MainActivity extends AppCompatActivity {
    //1ª Etapa: declarar as variáveis e a construção do nosso Array
    private ListView lista;
    private String[] itens = {"HTML5","CSS","SASS","Java","NodeJs","AngularJs","Ruby","React","jQuery"};

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        //2ª Etapa: mapeamento da lista
        lista = findViewById(R.id.lista);

        /*
        3ª Etapa: criar um adaptador para servir de ligação entre o Array e o elemento ListView no XML
        O adaptador vem do atributo ArrayAdapter
        android.R.layout.simple_list_item_1: mapeamento define o tipo da lista, ou seja, uma lista simples no layout atual - item 1;
        android.R.id.text1,itens: mapeamento que define os tipos de valores da lista
         */
        ArrayAdapter<String> adapter = new ArrayAdapter<String>(getApplicationContext(),
                android.R.layout.simple_list_item_1,android.R.id.text1,itens);

        //4ª Etapa: adicionar o adapter para a lista criada no Array
        lista.setAdapter(adapter);

        //5ª Etapa: print na tela em Toast indicando qual o item que foi clicado.
        //eventos: setOnItemClickListener e onItemClick
        lista.setOnItemClickListener(new AdapterView.OnItemClickListener() {
            @Override
            public void onItemClick(AdapterView<?> parent, View view, int i, long id) {
                Toast.makeText(MainActivity.this,itens[i],Toast.LENGTH_SHORT).show();
                switch (i)
                {
                    case 3:
                        abrirJavaScript();
                        break;
                }
            }
        });
    }

    private void abrirJavaScript()
    {
        Intent janela = new Intent(this, JavaScript.class);
        startActivity(janela);
        finish();
    }


}